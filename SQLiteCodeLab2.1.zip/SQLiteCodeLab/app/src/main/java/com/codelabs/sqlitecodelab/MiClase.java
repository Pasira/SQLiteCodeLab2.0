package com.codelabs.sqlitecodelab;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Vector;

//Clase encargada de crear o actualizar la BD si es necesario.
public class MiClase extends SQLiteOpenHelper {
    public MiClase(Context context){
        super(context, "base_de_datos", null, 1);
    }

    //Método que se ejecuta si la BD no está creada.
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE tabla (_id INTEGER PRIMARY KEY AUTOINCREMENT, texto TEXT, entero INTEGER, numero REAL)");
    }

    //Método que se ejecuta si ha habido alguna modificación en la BD.
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newerVersion){

    }

    //Método con el que vamos a realizar una inserción de un registro de la tabla "tabla" pasándole 3 parámetros.
    public void guardar(String texto, int entero, double numero){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO tabla VALUES(null, "+"'"+texto+"', "+entero + ", "+ numero + ")");

    }

    public void borrar(int nId ) {
        SQLiteDatabase db = getReadableDatabase();
        db.execSQL("DELETE FROM tabla WHERE _id=" + nId);

    }

    public void actualizar(){

    }

    //Método que realiza una consulta sobre la tabla "tabla" de nuestra BD y devuelve el resultado de la consulta en un vector de Strings
    public Vector<String> consultar(int cantidad){

        //Vector que almacenará los registros obtenidos como resultado de la consulta.
        Vector<String> result = new Vector<String>();

        //Obtenemos la base de datos en modo de lectura.
        SQLiteDatabase db = getReadableDatabase();

        System.out.println("Ruta de la BD: " + db.getPath());

        //Ejecutamos la consulta con rawQuery y asignamos su resultado en el objeto Cursor.
        Cursor cursor = db.rawQuery("SELECT * FROM tabla ", null);

        //Un ejemplo de una consulta un poco más compleja. Hace uso del parámetro cantidad.
        //Cursor cursor = db.rawQuery("SELECT texto, entero FROM tabla WHERE numero>2 ORDER BY entero LIMIT " + cantidad, null);

        //Bucle que recorre todos los registros obtenidos en el cursor (equivalente a ResultSet en Java) y los introduce en el vector de Strings.
        while(cursor.moveToNext()){
            result.add(cursor.getInt(0) + ", " + cursor.getString(1) + ", " + cursor.getInt(2) + ", " + cursor.getDouble(3) + ".");
        }

        //Cierre de la conexión.
        cursor.close();
        return result;
    }
}
