package com.codelabs.sqlitecodelab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //Método que se ejecutará al hacer click en el botón "GUARDAR". Obtiene los valores de los textos de entrada, los convierte a los tipos correspondientes para la BD y llama al método guardar de la clase MiClase(gestora de la BD).
    public void guardarDatos(View v){
        EditText nombreIN = this.findViewById(R.id.nombreIN);
        EditText enteroIN = this.findViewById(R.id.enteroIN);
        EditText doubleIN = this.findViewById(R.id.doubleIN);
        EditText cantidadIN = this.findViewById(R.id.cantidadIN);
        LinearLayout lista = this.findViewById(R.id.lista);

        //Creamos un objeto de la clase MiClase para poder trabajar con la BD.
        MiClase bd = new MiClase(this);

        String texto = nombreIN.getText().toString();
        int entero = Integer.parseInt(enteroIN.getText().toString());
        double real = Double.parseDouble(doubleIN.getText().toString());

        bd.guardar(texto, entero, real);

    }

    public void actualizarDatos(View w) {
        EditText nombreAIN = this.findViewById(R.id.nombreAIN);
        EditText enteroAIN = this.findViewById(R.id.enteroAIN);
        EditText doubleAIN = this.findViewById(R.id.doubleAIN);
        EditText idAIn = this.findViewById(R.id.idAIN);

        MiClase bd = new MiClase(this);

        String textoA = nombreAIN.getText().toString();
        int enteroA = Integer.parseInt(enteroAIN.getText().toString());
        double realA = Double.parseDouble(doubleAIN.getText().toString());
        int idA = Integer.parseInt(idAIn.getText().toString());


        bd.actualizar(textoA, enteroA, realA, idA);
    }

    public void borrarDatos(View v){
        MiClase bd = new MiClase(this);
        EditText idIn = this.findViewById(R.id.idIN);
        int id = Integer.parseInt(idIn.getText().toString());

        bd.borrar(id);
    }

    //Método que se ejecutará al hacer click en el botón "MOSTRAR", Obtiene el valor del "TextView" cantidad y ejecuta una consulta sobre la tabla "tabla" devolviendo todos sus registros.
    public void mostrarDatos(View v){
        //Se crean los objetos necesarios para manejar las views del layout.
        LinearLayout lista = this.findViewById(R.id.lista); //LinearLayout que está contenido en la vista en un ScrollableView y que mostrará los registros obtenidos de la consulta.

        //Creamos un objeto de la clase MiClase para poder trabajar con la BD.
        MiClase bd = new MiClase(this);

        Vector <String> result = new Vector<String>();

        //Llamada al método de la clase MiClase que interacciona directamente con la BD.
        result = bd.consultar();

        lista.removeAllViews();

        //Bucle que añade cada String obtenida en el objeto result en la lista scrollable del layout.
        for (String s: result){
            TextView linea = new TextView(this);
            linea.setText(s);
            lista.addView(linea);
        }
    }

}
